# HammerLang Examples

Esta carpeta contiene ejemplos validados de código HammerLang del dominio **Logic Lock Protocol v1.3**.

## Uso rápido

Para decodificar cualquier ejemplo:

```bash
python ../hammerlang.py decode "$(cat dual_threshold.hml)"
```

Luego copia el output completo y pégalo en cualquier LLM (Claude, ChatGPT, Gemini, Grok).

---

## Ejemplos disponibles

### 1. `dual_threshold.hml` - Dual-Threshold Lock State

**Código:**
```
#LLP:DTL:v1.0
!LOCK⋈⦿[@E(G)<θ↓,Δ⧖(ε↑,k),σ²>V⋔μ<~E-σ]%dancing ⊨84822398
```

**Expande a:**
```
The Dual-Threshold Lock State triggers if ANY of the following:
(1) E(G) < θ_lock [absolute degradation]
(2) signed_rate(t) < -ε_sensitivity for k windows [rate-based]
(3) Var(E[t-τ:t]) > V_threshold AND mean(E) < E_baseline - σ
[omitted: dancing - refers to variance-based detection of oscillating coherence]
```

**Compresión:** 2.29x (24 tokens → 55 tokens expandido)

---

### 2. `fsm_hybrid.hml` - FSM State Transitions

**Código:**
```
#LLP:FSM:v1.0
!FSM⋈[S0→S1:<θ|░A; S1→S2:Δ≺ε*k|σ>th; S2→S3:⟂|░X; S3→S0:░R] ⊨008932b2
```

**Expande a:**
```
Finite State Machine with four states:
- NORMAL (S0) → DETECT (S1): coherence < threshold OR anomaly A detected
- DETECT (S1) → LOCKED (S2): rate degradation < epsilon for k windows OR variance > threshold
- LOCKED (S2) → RECOVER (S3): explicit override OR exception X
- RECOVER (S3) → NORMAL (S0): recovery procedure R succeeds
```

**Compresión:** 2.77x (30 tokens → 83 tokens expandido)

---

### 3. `lock_signal.hml` - Standardized Lock Signal

**Código:**
```
#LLP:SIG:v1.0
!SIG⊢[protocol_id|HALT|AxB|ΔE=0.87|ts=1640995200] ⊨4a7f8964
```

**Expande a:**
```
Standardized lock signal:
- Protocol: Logic Lock Protocol v1.3
- Action: HALT
- Affected systems: A × B (cross-product)
- Coherence delta: ΔE = 0.87
- Timestamp: 1640995200 (Unix ms)
```

**Compresión:** 4.11x (9 tokens → 37 tokens expandido)

---

### 4. `implicit_contradiction.hml` - Implicit Contradiction Detection

**Código:**
```
#LLP:IMP:v1.0
!IMP⊧[P∧¬P|¬⊧¬P|⦉buried⦊] ⊨5374f6c5
```

**Expande a:**
```
The system detects implicit contradictions through multi-hop reasoning:
if proposition P and its negation ¬P are both asserted,
or if the negation of P cannot be proven false (¬⊧¬P),
and this contradiction is buried deep in the reasoning chain
rather than surface-level, trigger the implicit contradiction handler.
```

**Compresión:** 3.94x (17 tokens → 67 tokens expandido)

---

### 5. `lora_threat.hml` - LoRA Bypass Threat

**Código:**
```
#LLP:THR:v1.0
!THR⊢[adapterΔ|¬E(G)match|reject|~high] ⊨8028d9c1
```

**Expande a:**
```
Detect potential LoRA or PEFT adapter bypass attacks:
if adapter introduces delta modifications that cause E(G) coherence mismatch
compared to baseline, reject the adapter and flag as high-severity threat.
```

**Compresión:** 4.11x (9 tokens → 37 tokens expandido)

---

## Validación

Todos los ejemplos han sido validados con checksums correctos:

```bash
# Validar sintaxis y checksum
python ../hammerlang.py validate "$(cat dual_threshold.hml)"
# ✅ Sintaxis OK
# ✅ Checksum válido: 84822398
```

---

## Crear tus propios ejemplos

1. Escribe tu especificación en formato HammerLang (sin checksum)
2. Genera el checksum:
   ```bash
   python ../hammerlang.py checksum "tu código aquí"
   ```
3. Agrega el checksum al final: `⊨XXXXXXXX`
4. Valida:
   ```bash
   python ../hammerlang.py validate "tu código completo"
   ```

---

## Contribuir

¿Tienes ejemplos de otros dominios? ¿Casos de uso interesantes?

Abre un PR en el repo principal con:
- Tu archivo `.hml`
- Descripción del caso de uso
- Expansión esperada
- Ratio de compresión medido

---

**Promedio de compresión en estos ejemplos:** 3.44x (69% ahorro de tokens)
